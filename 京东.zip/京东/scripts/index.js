//关闭顶部图片
var gb=document.getElementsByClassName("close")[0];
	var imgg=document.getElementsByClassName("close-img")[0];
	gb.onclick=function(){
		imgg.style.display="none";
		
	}
//导航栏上面搜索框
window.onscroll=function(){
	var Dao=document.getElementsByClassName("FixedSearch")[0];
	var top=document.documentElement.scrollTop?document.documentElement.scrollTop:document.body.scrollTop;
	var DaoH=Dao.offsetHeight;
	if(top>=550){
		Dao.style.display="block"
	var	ti1=setInterval(function(){
			DaoH=DaoH+2
			if(DaoH>=48){
				DaoH=48;
				clearInterval(ti1);
			}
			Dao.style.height=DaoH+"px";
		},10)
		
	
	}else{
	
		Dao.style.display="none"
	}

}



//导航栏下轮播图
var $img_a = $(".banner .img .banner_img_a");
var $indicator = $(".indicator span");


// 表示当前轮播到第几张图片了
var index = 0;

// 开启自动轮播
var interval = setInterval(changeIndex,3000);

// 改变 index
function changeIndex(){
	// 获取下一张索引
	index = index >= $img_a.length - 1 ? 0 : index+1;
	// 切换图片
	changeImage();
}

// 切换图片
function changeImage(){
	$img_a.eq(index).fadeIn("fast").siblings().fadeOut("fast");
	$indicator.eq(index).addClass("cur").siblings().removeClass("cur");
}

// 当鼠标移到页标指示器上
$indicator.hover(function(){
	// 停止自动轮播
	clearInterval(interval);
	// 获取当前鼠标移到span的索引
	index = $(this).index();
	// 切换图片
	changeImage();
},function(){
	// 继续自动轮播
	interval = setInterval(changeIndex,3000);
});

// 点击上一页
$(".page .prev").click(function(){
	// 获取上一张索引
	index = index <= 0 ? $img_a.length - 1 : index-1;
	// 切换图片
	changeImage();
});
// 点击下一页
$(".page .next").click(function(){
	changeIndex();
});


$(".news-top ul .li2").mouseenter(function(){
	$(".news-top ul .li1 .div1").css(
		"display","none"
	)
	$(".news-top ul .li2 .div2").css(
		"display","block"
	)
});



//移动到鼠标消息上显示
$(".news-top ul li").mouseleave(function(){
	$(".news-top ul .li2 .div2").css(
		"display","none"
	)
	$(".news-top ul .li1 .div1").css(
		"display","block"
	)
});


//京东秒杀
var H=document.getElementsByClassName("houer")[0];
var m=document.getElementsByClassName("mins")[0];
var s=document.getElementsByClassName("ss")[0];
setInterval(function(){
	if(parseInt(H.innerHTML)>0){
		H.innerHTML=parseInt(H.innerHTML)-1;
	}else{
		alert("秒杀结束");
	}
},3600000)
setInterval(function(){
	if (parseInt(m.innerHTML)>0) {
		m.innerHTML=parseInt(m.innerHTML)-1;
	}else{
		H.innerHTML=parseInt(H.innerHTML)-1;
	}
},60000)
setInterval(function(){
	if(parseInt(s.innerHTML)>0){
		s.innerHTML=parseInt(s.innerHTML)-1;
		if(Number(s.innerHTML)<10&&Number(s.innerHTML)>0) s.innerHTML="0"+s.innerHTML;
		
	}else{
		m.innerHTML=parseInt(m.innerHTML)-1;
		s.innerHTML=60;
	}
},1000)


//享品质小轮播
var $img_a2 = $(".QualityGoods .banner .img .banner_img_a");
var $indicator2= $(".QualityGoods .indicator span");


// 表示当前轮播到第几张图片了
var index2 = 0;

// 开启自动轮播
var interval2 = setInterval(changeIndex2,3000);

// 改变 index
function changeIndex2(){
	// 获取下一张索引
	index2 = index2 >= $img_a2.length - 1 ? 0 : index2+1;
	// 切换图片
	changeImage2();
}

// 切换图片
function changeImage2(){
	$img_a2.eq(index2).fadeIn("fast").siblings().fadeOut("fast");
	$indicator2.eq(index2).addClass("cur").siblings().removeClass("cur");
}

// 当鼠标移到页标指示器上
$indicator2.hover(function(){
	// 停止自动轮播
	clearInterval(interval2);
	// 获取当前鼠标移到span的索引
	index2 = $(this).index();
	// 切换图片
	changeImage2();
},function(){
	// 继续自动轮播
	interval2 = setInterval(changeIndex2,3000);
});

// 点击上一页
$(".QualityGoods .page .prev").click(function(){
	// 获取上一张索引
	index2 = index2 <= 0 ? $img_a2.length - 1 : index2-1;
	// 切换图片
	changeImage2();
});
// 点击下一页
$(".QualityGoods .page .next").click(function(){
	changeIndex2();
});


//左侧楼层
var arr=[];
$(".protal_body .protal_body_left").each(function(){
    arr.push($(this).offset().top);
    return arr;
});
$(window).scroll(function(){
    var top=$(this).scrollTop();
    if(top>arr[0]-300){
        $(".elevator").show();
    }else{
        $(".elevator").hide();
    }
    for(var i=0;i<arr.length;i++){
        if(top>arr[i]-500){
            index=i;
            $(".elevator").children().filter("ul").children().each(function(){
                $(this).children().filter("span").css({display:"none"})
            });
            $(".elevator").children().filter("ul").children().eq(i).children().filter("span").css({display:"block"});
        }
    }
});
$(".elevator").children().filter("ul").children().hover(function(){
    $(this).children().filter("span").css({display:"block"});
},function(){
    if(index==$(this).index()){
        return;
    }
    $(this).children().filter("span").css({display:"none"});
});
$(".elevator").children().filter("ul").children().click(function(){
    $("html,body").animate({scrollTop:arr[$(this).index()]-50});
})



//右侧功能分类

var flbtn=$(".flbtn");
var des=$(".description");
var fenlei=$(".fenlei")
for (var i = 0; i < fenlei.length; i++) {
    fenlei[i].index=i;
    fenlei[i].onmouseover=function(){
        flbtn[this.index].style.backgroundColor="#CA1623";
        des[this.index].style.backgroundColor="#CA1623";
        animate(des[this.index],{left:-62},400);
    }
    fenlei[i].onmouseout=function(){
        flbtn[this.index].style.backgroundColor="#7A6E6E";
        des[this.index].style.backgroundColor="#7A6E6E";
        animate(des[this.index],{left:0},400);
    }
};

 $(".back").click(function(){
    $("html,body").animate({scrollTop:0})
   })



